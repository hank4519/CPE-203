import processing.core.PImage;

import java.util.List;

public class GoldObstacle extends Entity{
    public GoldObstacle(String id, Point position, List<PImage> images)
    {
        super(id, position, images);
    }
}
