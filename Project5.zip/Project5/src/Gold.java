import processing.core.PImage;

import java.util.List;

public class Gold extends Entity{
    public Gold(String id, Point position, List<PImage> images)
    {
        super(id, position, images);
    }
    public Gold(){}
}
