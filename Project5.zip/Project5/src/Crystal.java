import processing.core.PImage;

import java.util.List;

public class Crystal extends Entity{
    public Crystal(String id, Point position, List<PImage> images)
    {
        super(id, position, images);
    }
}

