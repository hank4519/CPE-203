import processing.core.PImage;

public interface Image {
    PImage getCurrentImage();
    void nextImage();
}
