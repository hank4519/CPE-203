import processing.core.PImage;

import java.util.List;

public abstract class Octo extends MoveEntity{

    protected int resourceCount;
    protected int resourceLimit;

    public Octo(String id, Point position, List<PImage> images, int resourceLimit, int resourceCount, int actionPeriod, int animationPeriod, PathingStrategy strategy){
        super(id, position, images, actionPeriod, animationPeriod, strategy);
        this.resourceCount = resourceCount;
        this.resourceLimit = resourceLimit;
    }
    public void scheduleAction( EventScheduler scheduler,
                                WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, null, null,0), this.animationPeriod);
    }

    protected abstract boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
//    public Point nextPosition(WorldModel world, Point destPos){
//        List<Point> list = strategy.computePath(this.position, destPos, p -> world.withinBounds(p) && !world.getOccupant(p).isPresent(),
//                (p1,p2)-> p1.neighbor(p2), PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);
//        return list.isEmpty()? null: list.get(0);
//
//    }
        public Point nextPosition(WorldModel world, Point destPos){
        int horiz = Integer.signum(destPos.getX() - this.position.getX());
        Point newPos = new Point(this.position.getX() + horiz,
                this.position.getY());

        if (horiz == 0 || world.isOccupied(newPos))
        {
            int vert = Integer.signum(destPos.getY() - this.position.getY());
            newPos = new Point(this.position.getX(),
                    this.position.getY() + vert);

            if (vert == 0 || world.isOccupied(newPos))
            {
                newPos = this.position;
            }
        }

        return newPos;
    }
}
