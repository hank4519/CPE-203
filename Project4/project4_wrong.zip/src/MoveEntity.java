import processing.core.PImage;

import java.util.List;

public abstract class MoveEntity extends AnimationActionEntity {
    protected PathingStrategy strategy;
    public MoveEntity(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, PathingStrategy strategy){
        super(id, position, images, actionPeriod, animationPeriod);
        this.strategy = strategy;
    }
//    public Point nextPosition(WorldModel world, Point destPos){
//        int horiz = Integer.signum(destPos.getX() - this.position.getX());
//        Point newPos = new Point(this.position.getX() + horiz,
//                this.position.getY());
//
//        if (horiz == 0 || world.isOccupied(newPos))
//        {
//            int vert = Integer.signum(destPos.getY() - this.position.getY());
//            newPos = new Point(this.position.getX(),
//                    this.position.getY() + vert);
//
//            if (vert == 0 || world.isOccupied(newPos))
//            {
//                newPos = this.position;
//            }
//        }
//
//        return newPos;
//    }
    abstract Point nextPosition(WorldModel world, Point destPos);
    abstract boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler);

}
