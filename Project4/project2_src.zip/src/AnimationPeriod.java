public interface AnimationPeriod {
    int getAnimationPeriod();
}
