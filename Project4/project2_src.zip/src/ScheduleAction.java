public interface ScheduleAction {
    void scheduleAction( EventScheduler scheduler, WorldModel world, ImageStore imageStore);
}
