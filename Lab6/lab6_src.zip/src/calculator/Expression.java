package calculator;

public abstract class Expression
   implements Operation
{
}
