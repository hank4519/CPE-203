public class CircleException extends RuntimeException{
    public CircleException(String msg){
        super(msg);
    }
}
