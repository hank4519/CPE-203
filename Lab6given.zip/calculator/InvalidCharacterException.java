class InvalidCharacterException
   extends ScannerException
{
}
